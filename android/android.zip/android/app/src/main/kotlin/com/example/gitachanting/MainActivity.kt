package com.example.gitachanting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
